%PROGRAMNAME% translation instructions

1) Just create a new translation by clicking
   the "Create NEW translation button" or open
   an existing translation by clicking the "Open 
   translation" button.

2) Now, just translate the TWO files. You can
   switch between the 2 files by selecting
   them from the box (User interface or Messages)

3) When translating the User interface is VERY
   important that you mantain the length of the
   strings. If your string is much longer than
   the original, the user interface may end being
   deformed.

4) When tranlating the messages is VITAL, VERY
   IMPORTANT that the number AND ORDER of the 
   parameters %s and %d will be THE SAME than 
   the original. If you do not so, the engine 
   may die a painfull death because several 
   exceptions may happen.

5) Before you ship your files, check the translation
   clicking on the "Check all lines" button. This 
   checks the number of %s and %d in every line but 
   DOESN'T check the order. Please, be sure that if 
   a line contains the string '%s done. %d files copied'
   you DON'T translate it '%d files copied. %s done'.
   The order of %s and %d in a phrase is VITAL.

6) When you have tested your files, send them to me
   cobian@educ.umu.se
