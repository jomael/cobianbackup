� 2000-2005 by Luis Cobian

Use this utility to create a script to automatically install Cobian Backup 7. 

Enter all the information and save the script as Cb7Auto.txt in **THE SAME FOLDER** where your setup Cb7Setup.exe is located. If you do so, the setup will detect the file and the installation will be done without any interaction with the user. This is great when you are installing the program in many computers.
